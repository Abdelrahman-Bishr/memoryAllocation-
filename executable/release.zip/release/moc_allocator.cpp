/****************************************************************************
** Meta object code from reading C++ file 'allocator.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../memoryAllocation/allocator.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'allocator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Allocator_t {
    QByteArrayData data[14];
    char stringdata0[172];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Allocator_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Allocator_t qt_meta_stringdata_Allocator = {
    {
QT_MOC_LITERAL(0, 0, 9), // "Allocator"
QT_MOC_LITERAL(1, 10, 13), // "holeAllocated"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 5), // "Hole*"
QT_MOC_LITERAL(4, 31, 13), // "allocatedHole"
QT_MOC_LITERAL(5, 45, 9), // "holeEaten"
QT_MOC_LITERAL(6, 55, 8), // "holeName"
QT_MOC_LITERAL(7, 64, 17), // "deallocateProcess"
QT_MOC_LITERAL(8, 82, 8), // "Process*"
QT_MOC_LITERAL(9, 91, 19), // "processToDeallocate"
QT_MOC_LITERAL(10, 111, 8), // "setHoles"
QT_MOC_LITERAL(11, 120, 17), // "std::list<Hole*>*"
QT_MOC_LITERAL(12, 138, 12), // "setProcesses"
QT_MOC_LITERAL(13, 151, 20) // "std::list<Process*>*"

    },
    "Allocator\0holeAllocated\0\0Hole*\0"
    "allocatedHole\0holeEaten\0holeName\0"
    "deallocateProcess\0Process*\0"
    "processToDeallocate\0setHoles\0"
    "std::list<Hole*>*\0setProcesses\0"
    "std::list<Process*>*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Allocator[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   39,    2, 0x06 /* Public */,
       5,    1,   42,    2, 0x06 /* Public */,
       7,    1,   45,    2, 0x06 /* Public */,
      10,    0,   48,    2, 0x06 /* Public */,
      12,    0,   49,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Bool, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, 0x80000000 | 8,    9,
    0x80000000 | 11,
    0x80000000 | 13,

       0        // eod
};

void Allocator::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Allocator *_t = static_cast<Allocator *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: { bool _r = _t->holeAllocated((*reinterpret_cast< Hole*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 1: _t->holeEaten((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->deallocateProcess((*reinterpret_cast< Process*(*)>(_a[1]))); break;
        case 3: { std::list<Hole*>* _r = _t->setHoles();
            if (_a[0]) *reinterpret_cast< std::list<Hole*>**>(_a[0]) = _r; }  break;
        case 4: { std::list<Process*>* _r = _t->setProcesses();
            if (_a[0]) *reinterpret_cast< std::list<Process*>**>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Process* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef bool (Allocator::*_t)(Hole * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Allocator::holeAllocated)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Allocator::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Allocator::holeEaten)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Allocator::*_t)(Process * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Allocator::deallocateProcess)) {
                *result = 2;
                return;
            }
        }
        {
            typedef std::list<Hole*> * (Allocator::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Allocator::setHoles)) {
                *result = 3;
                return;
            }
        }
        {
            typedef std::list<Process*> * (Allocator::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Allocator::setProcesses)) {
                *result = 4;
                return;
            }
        }
    }
}

const QMetaObject Allocator::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Allocator.data,
      qt_meta_data_Allocator,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Allocator::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Allocator::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Allocator.stringdata0))
        return static_cast<void*>(const_cast< Allocator*>(this));
    return QObject::qt_metacast(_clname);
}

int Allocator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
bool Allocator::holeAllocated(Hole * _t1)
{
    bool _t0 = bool();
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)), const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
    return _t0;
}

// SIGNAL 1
void Allocator::holeEaten(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Allocator::deallocateProcess(Process * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
std::list<Hole*> * Allocator::setHoles()
{
    std::list<Hole*>* _t0 = 0;
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
    return _t0;
}

// SIGNAL 4
std::list<Process*> * Allocator::setProcesses()
{
    std::list<Process*>* _t0 = 0;
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
    return _t0;
}
QT_END_MOC_NAMESPACE
