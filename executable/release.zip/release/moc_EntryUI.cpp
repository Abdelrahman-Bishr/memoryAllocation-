/****************************************************************************
** Meta object code from reading C++ file 'EntryUI.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../memoryAllocation/EntryUI.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'EntryUI.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_EntryUI_t {
    QByteArrayData data[37];
    char stringdata0[508];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_EntryUI_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_EntryUI_t qt_meta_stringdata_EntryUI = {
    {
QT_MOC_LITERAL(0, 0, 7), // "EntryUI"
QT_MOC_LITERAL(1, 8, 7), // "addHole"
QT_MOC_LITERAL(2, 16, 0), // ""
QT_MOC_LITERAL(3, 17, 10), // "addProcess"
QT_MOC_LITERAL(4, 28, 10), // "addSegment"
QT_MOC_LITERAL(5, 39, 7), // "popHole"
QT_MOC_LITERAL(6, 47, 26), // "std::list<Hole*>::iterator"
QT_MOC_LITERAL(7, 74, 10), // "popProcess"
QT_MOC_LITERAL(8, 85, 10), // "popSegment"
QT_MOC_LITERAL(9, 96, 13), // "buttonClicked"
QT_MOC_LITERAL(10, 110, 15), // "ControlButtons*"
QT_MOC_LITERAL(11, 126, 12), // "sourceButton"
QT_MOC_LITERAL(12, 139, 15), // "startAllocation"
QT_MOC_LITERAL(13, 155, 15), // "processSelected"
QT_MOC_LITERAL(14, 171, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(15, 188, 15), // "selectedProcess"
QT_MOC_LITERAL(16, 204, 12), // "holeSelected"
QT_MOC_LITERAL(17, 217, 12), // "selectedHole"
QT_MOC_LITERAL(18, 230, 15), // "segmentSelected"
QT_MOC_LITERAL(19, 246, 15), // "selectedSegment"
QT_MOC_LITERAL(20, 262, 13), // "setMemorySize"
QT_MOC_LITERAL(21, 276, 8), // "sizeText"
QT_MOC_LITERAL(22, 285, 13), // "holeAllocated"
QT_MOC_LITERAL(23, 299, 5), // "Hole*"
QT_MOC_LITERAL(24, 305, 13), // "allocatedHole"
QT_MOC_LITERAL(25, 319, 18), // "segmentDeallocated"
QT_MOC_LITERAL(26, 338, 8), // "Segment*"
QT_MOC_LITERAL(27, 347, 18), // "deallocatedSegment"
QT_MOC_LITERAL(28, 366, 24), // "removeHoleFromListWidget"
QT_MOC_LITERAL(29, 391, 8), // "holeName"
QT_MOC_LITERAL(30, 400, 17), // "deallocateProcess"
QT_MOC_LITERAL(31, 418, 8), // "Process*"
QT_MOC_LITERAL(32, 427, 19), // "processToDeallocate"
QT_MOC_LITERAL(33, 447, 12), // "getProcesses"
QT_MOC_LITERAL(34, 460, 20), // "std::list<Process*>*"
QT_MOC_LITERAL(35, 481, 8), // "getHoles"
QT_MOC_LITERAL(36, 490, 17) // "std::list<Hole*>*"

    },
    "EntryUI\0addHole\0\0addProcess\0addSegment\0"
    "popHole\0std::list<Hole*>::iterator\0"
    "popProcess\0popSegment\0buttonClicked\0"
    "ControlButtons*\0sourceButton\0"
    "startAllocation\0processSelected\0"
    "QListWidgetItem*\0selectedProcess\0"
    "holeSelected\0selectedHole\0segmentSelected\0"
    "selectedSegment\0setMemorySize\0sizeText\0"
    "holeAllocated\0Hole*\0allocatedHole\0"
    "segmentDeallocated\0Segment*\0"
    "deallocatedSegment\0removeHoleFromListWidget\0"
    "holeName\0deallocateProcess\0Process*\0"
    "processToDeallocate\0getProcesses\0"
    "std::list<Process*>*\0getHoles\0"
    "std::list<Hole*>*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_EntryUI[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  109,    2, 0x08 /* Private */,
       3,    0,  110,    2, 0x08 /* Private */,
       4,    0,  111,    2, 0x08 /* Private */,
       5,    0,  112,    2, 0x08 /* Private */,
       7,    0,  113,    2, 0x08 /* Private */,
       8,    0,  114,    2, 0x08 /* Private */,
       9,    1,  115,    2, 0x08 /* Private */,
      12,    0,  118,    2, 0x08 /* Private */,
      13,    1,  119,    2, 0x08 /* Private */,
      16,    1,  122,    2, 0x08 /* Private */,
      18,    1,  125,    2, 0x08 /* Private */,
      20,    1,  128,    2, 0x08 /* Private */,
      22,    1,  131,    2, 0x08 /* Private */,
      25,    1,  134,    2, 0x08 /* Private */,
      28,    1,  137,    2, 0x08 /* Private */,
      30,    1,  140,    2, 0x08 /* Private */,
      33,    0,  143,    2, 0x08 /* Private */,
      35,    0,  144,    2, 0x08 /* Private */,
      30,    0,  145,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void, 0x80000000 | 14,   17,
    QMetaType::Void, 0x80000000 | 14,   19,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Bool, 0x80000000 | 23,   24,
    QMetaType::Void, 0x80000000 | 26,   27,
    QMetaType::Void, QMetaType::QString,   29,
    QMetaType::Void, 0x80000000 | 31,   32,
    0x80000000 | 34,
    0x80000000 | 36,
    QMetaType::Void,

       0        // eod
};

void EntryUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        EntryUI *_t = static_cast<EntryUI *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->addHole(); break;
        case 1: _t->addProcess(); break;
        case 2: _t->addSegment(); break;
        case 3: { std::list<Hole*>::iterator _r = _t->popHole();
            if (_a[0]) *reinterpret_cast< std::list<Hole*>::iterator*>(_a[0]) = _r; }  break;
        case 4: _t->popProcess(); break;
        case 5: _t->popSegment(); break;
        case 6: _t->buttonClicked((*reinterpret_cast< ControlButtons*(*)>(_a[1]))); break;
        case 7: _t->startAllocation(); break;
        case 8: _t->processSelected((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 9: _t->holeSelected((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 10: _t->segmentSelected((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 11: _t->setMemorySize((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: { bool _r = _t->holeAllocated((*reinterpret_cast< Hole*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 13: _t->segmentDeallocated((*reinterpret_cast< Segment*(*)>(_a[1]))); break;
        case 14: _t->removeHoleFromListWidget((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 15: _t->deallocateProcess((*reinterpret_cast< Process*(*)>(_a[1]))); break;
        case 16: { std::list<Process*>* _r = _t->getProcesses();
            if (_a[0]) *reinterpret_cast< std::list<Process*>**>(_a[0]) = _r; }  break;
        case 17: { std::list<Hole*>* _r = _t->getHoles();
            if (_a[0]) *reinterpret_cast< std::list<Hole*>**>(_a[0]) = _r; }  break;
        case 18: _t->deallocateProcess(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< ControlButtons* >(); break;
            }
            break;
        case 13:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Segment* >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Process* >(); break;
            }
            break;
        }
    }
}

const QMetaObject EntryUI::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_EntryUI.data,
      qt_meta_data_EntryUI,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *EntryUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *EntryUI::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_EntryUI.stringdata0))
        return static_cast<void*>(const_cast< EntryUI*>(this));
    return QWidget::qt_metacast(_clname);
}

int EntryUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
